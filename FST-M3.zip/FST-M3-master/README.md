# IBM FST M3 Submission Repo

In Module 3, you only have to submit your project work.

There are 2 folders in this repository, `Docker Project` and `Kubernetes Project`.

For the Docker Project, please upload only your Dockerfile.dev, Dockerfile, docker-compose.yml, and any .jmx files you have written.

For the Kubernetes Project, please upload any and all configuration files you have written.
